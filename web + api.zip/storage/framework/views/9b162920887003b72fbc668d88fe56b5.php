<?php $__env->startSection('title', 'User'); ?>
<?php $__env->startSection('subtitle', 'Daftar'); ?>

<?php $__env->startSection('dashboard', 'collapsed'); ?>
<?php $__env->startSection('materi', 'collapsed'); ?>
<?php $__env->startSection('jobsheet', 'collapsed'); ?>
<?php $__env->startSection('user', ''); ?>
<?php $__env->startSection('add', 'collapsed'); ?>
<?php $__env->startSection('log-jobsheet', 'collapsed'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body pt-4">
                <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-sm btn-success my-3">
                    <i class="bi bi-plus"></i> Tambah
                </a>
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th><i class="bi bi-gear"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td>
                                    <form method="POST" id="form-reset-password"
                                        action="<?php echo e(route('admin.user.update', $item->id)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="button" class="btn btn-sm btn-warning btn-reset-password"
                                            data-id="<?php echo e($item->id); ?>">
                                            Reset Password
                                        </button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('admin.user.destroy', $item->id)); ?>"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-sm btn-danger btn-delete"
                                            data-id="<?php echo e($item->id); ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const resetPasswordButtons = document.querySelectorAll('.btn-reset-password');

            resetPasswordButtons.forEach(function(button) {
                button.addEventListener('click', function() {
                    const form = button.closest('form');


                    Swal.fire({
                        title: 'Apakah anda yakin mereset password ini?',
                        text: "Data akan memiliki password default 'password'!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#ffc107',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'Ya, reset!',
                        cancelButtonText: 'Batal'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views/admin/user/index.blade.php ENDPATH**/ ?>