<?php $__env->startSection('title', 'Materi'); ?>
<?php $__env->startSection('subtitle', 'Edit'); ?>

<?php $__env->startSection('dashboard', 'collapsed'); ?>
<?php $__env->startSection('materi', ''); ?>
<?php $__env->startSection('jobsheet', 'collapsed'); ?>
<?php $__env->startSection('add', 'collapsed'); ?>
<?php $__env->startSection('log-jobsheet', 'collapsed'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Edit Materi</h5>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <strong>Periksa kembali!</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.materi.update', $materi->id)); ?>" method="POST" enctype="multipart/form-data"
                    class="row g-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="col-md-6">
                        <label for="title" class="form-label">Judul</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $materi->title)); ?>"
                            required>
                    </div>

                    <div class="col-md-6">
                        <label for="duration" class="form-label">Durasi</label>
                        <input type="text" name="duration" class="form-control"
                            value="<?php echo e(old('duration', $materi->duration)); ?>" required>
                    </div>

                    <div class="col-md-12">
                        <label for="konten" class="form-label">Konten</label>
                        <!-- Quill Editor Default -->
                        <textarea class="tinymce-editor" name="konten" id="konten" rows="10" required>
                            <?php echo e(old('konten', $materi->konten)); ?>

                        </textarea>
                    </div>

                    <div class="col-md-12">
                        <label for="link_pdf" class="form-label">Upload PDF Baru (opsional)</label>
                        <input type="file" name="link_pdf" class="form-control" accept="application/pdf">
                        <small class="text-muted">File saat ini: <a href="<?php echo e(asset('storage/' . $materi->link_pdf)); ?>"
                                target="_blank">Lihat PDF</a></small>
                    </div>

                    <div class="text-start">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(route('admin.materi.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var quill = new Quill('#quill_editor', {
            theme: 'snow'
        });

        // Isi konten awal dari input hidden
        var kontenAwal = document.getElementById('konten_data').value;
        if (kontenAwal) {
            quill.root.innerHTML = kontenAwal;
        }

        // Sync isi konten ke input hidden sebelum submit
        const form = document.querySelector('form');
        form.onsubmit = function() {
            document.getElementById('konten_input').value = quill.root.innerHTML;
        };
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views\admin\materi\edit.blade.php ENDPATH**/ ?>