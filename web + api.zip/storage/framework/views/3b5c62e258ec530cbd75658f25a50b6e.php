<?php $__env->startSection('title', 'Adds'); ?>
<?php $__env->startSection('subtitle', 'Daftar'); ?>

<?php $__env->startSection('dashboard', 'collapsed'); ?>
<?php $__env->startSection('materi', 'collapsed'); ?>
<?php $__env->startSection('jobsheet', 'collapsed'); ?>
<?php $__env->startSection('add', ''); ?>
<?php $__env->startSection('log-jobsheet', 'collapsed'); ?>
<?php $__env->startSection('user', 'collapsed'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body pt-4">
                <a href="<?php echo e(route('admin.add.create')); ?>" class="btn btn-sm btn-success my-3">
                    <i class="bi bi-plus"></i> Tambah
                </a>
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Link</th>
                            <th><i class="bi bi-gear"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->title); ?></td>
                                <td><a href="<?php echo e($item->link); ?>" target="_blank"><?php echo e($item->link); ?></a></td>
                                <td>
                                    <a href="<?php echo e(route('admin.add.edit', $item->id)); ?>" class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.add.destroy', $item->id)); ?>"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-sm btn-danger btn-delete"
                                            data-id="<?php echo e($item->id); ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views/admin/add/index.blade.php ENDPATH**/ ?>