<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('subtitle', 'dashboard'); ?>
<?php $__env->startSection('dashboard', ''); ?>
<?php $__env->startSection('materi', 'collapsed'); ?>
<?php $__env->startSection('jobsheet', 'collapsed'); ?>
<?php $__env->startSection('add', 'collapsed'); ?>
<?php $__env->startSection('log-jobsheet', 'collapsed'); ?>
<?php $__env->startSection('content'); ?>
    <section class="section dashboard">
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="row">

                    <!-- Jumlah Siswa Card -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card info-card sales-card">

                            <div class="card-body">
                                <h5 class="card-title">Siswa</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person-lines-fill"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($items['user']); ?></h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Jumlah Siswa Card -->

                    <!-- Jumlah Materi Card -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card info-card sales-card">

                            <div class="card-body">
                                <h5 class="card-title">Materi</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-journal-text"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($items['materi']); ?></h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Jumlah Materi Card -->
                    <!-- Jumlah Jobsheet Card -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card info-card sales-card">

                            <div class="card-body">
                                <h5 class="card-title">Jobsheet</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-file-earmark-text"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($items['jobsheet']); ?></h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Jumlah Jobsheet Card -->
                    <!-- Jumlah Add Card -->
                    <div class="col-sm-6 col-lg-3">
                        <div class="card info-card sales-card">

                            <div class="card-body">
                                <h5 class="card-title">Add</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-clipboard-plus"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($items['add']); ?></h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Jumlah Add Card -->
                </div>
            </div><!-- End Left side columns -->

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>