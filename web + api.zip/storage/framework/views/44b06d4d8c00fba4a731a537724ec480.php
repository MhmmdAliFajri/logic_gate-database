<?php $__env->startSection('title', 'Log Jobsheet'); ?>
<?php $__env->startSection('subtitle', 'Tambah'); ?>

<?php $__env->startSection('dashboard', 'collapsed'); ?>
<?php $__env->startSection('materi', 'collapsed'); ?>
<?php $__env->startSection('jobsheet', 'collapsed'); ?>
<?php $__env->startSection('add', 'collapsed'); ?>
<?php $__env->startSection('log-jobsheet', ''); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Tambah Log Jobsheet</h5>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <strong>Periksa kembali!</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.log-jobsheet.store')); ?>" method="POST" enctype="multipart/form-data"
                    class="row g-3">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-6">
                        <label for="user_id" class="form-label">User</label>
                        <select name="user_id" id="user_id" class="form-select" required>
                            <option value="">-- Pilih User --</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="jobsheet_id" class="form-label">Jobsheet</label>
                        <select name="jobsheet_id" id="jobsheet_id" class="form-select" required>
                            <option value="">-- Pilih Jobsheet --</option>
                            <?php $__currentLoopData = $jobsheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sheet->id); ?>"
                                    <?php echo e(old('jobsheet_id') == $sheet->id ? 'selected' : ''); ?>>
                                    <?php echo e($sheet->title); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="link_pdf" class="form-label">File PDF</label>
                        <input type="file" name="link_pdf" id="link_pdf" class="form-control" required
                            accept="application/pdf">
                    </div>

                    <div class="col-md-3">
                        <label for="nilai" class="form-label">Nilai</label>
                        <input type="number" name="nilai" id="nilai" class="form-control"
                            value="<?php echo e(old('nilai')); ?>">
                    </div>

                    <div class="col-md-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-select" required>
                            <option value="submitted" <?php echo e(old('status') == 'submitted' ? 'selected' : ''); ?>>Submitted
                            </option>
                            <option value="graded" <?php echo e(old('status') == 'graded' ? 'selected' : ''); ?>>Graded</option>
                            <option value="pending" <?php echo e(old('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        </select>
                    </div>

                    <div class="text-start">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('admin.log-jobsheet.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views\admin\log_jobsheet\create.blade.php ENDPATH**/ ?>