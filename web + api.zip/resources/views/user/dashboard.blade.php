@extends('layouts.master')

@section('content')
@section('dashboard', '')
@section('content')
    <section class="section dashboard">
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-title">
                        <h2 class="text-center"> Gunakan Aplikasi Android untuk mengakses pembelajaran ya ☺️☺️</h2>
                    </div>
                </div>
            </div><!-- End Left side columns -->

        </div>
    </section>
@endsection
